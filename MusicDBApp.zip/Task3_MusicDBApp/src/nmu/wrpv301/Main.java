package nmu.wrpv301;

import java.sql.Connection;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DBHandler dbHandler = new DBHandler();

        System.out.print("Enter DB username: ");
        String username = scanner.nextLine();

        System.out.print("Enter DB password: ");
        String password = scanner.nextLine();

        if (!dbHandler.connect(username, password)) {
            System.out.println("Connection failed. Exiting.");
            return;
        }

        while (true) {
            System.out.println("\n=== Music Database Menu ===");
            System.out.println("1. Create Album & Songs");
            System.out.println("2. Edit Album or Songs");
            System.out.println("3. Query Songs by Artist");
            System.out.println("4. Query Songs by Title Keyword");
            System.out.println("5. Query Albums by Title Keyword");
            System.out.println("0. Exit");
            System.out.print("Choice: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    dbHandler.createAlbumAndSongs();
                    break;
                case "2":
                    dbHandler.editAlbumOrSongs();
                    break;
                case "3":
                    dbHandler.querySongsByArtist();
                    break;
                case "4":
                    dbHandler.querySongsByTitleKeyword();
                    break;
                case "5":
                    dbHandler.queryAlbumsByTitleKeyword();
                    break;
                case "0":
                    dbHandler.disconnect();
                    System.out.println("Disconnected. Goodbye.");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}