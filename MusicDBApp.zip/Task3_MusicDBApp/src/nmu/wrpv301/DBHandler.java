package nmu.wrpv301;

import java.sql.*;
import java.util.Scanner;

public class DBHandler {

    private Connection conn; //establishes conn to db, create statement obj to create sql queries, checks if connected. also to close conn
    private final Scanner scanner = new Scanner(System.in);

    public boolean connect(String user, String pass) {
        try {
            conn = DriverManager.getConnection("jdbc:sqlserver://postsql.mandela.ac.za\\wrr;databaseName=WRAP301Music", user, pass);
            System.out.println("Connected to database.");
            return true;
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            return false;
        }
    }

    public void disconnect() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Disconnected from DB.");
            }
        } catch (SQLException e) {
            System.err.println("Error disconnecting: " + e.getMessage());
        }
    }

    public void createAlbumAndSongs() {
        try {
            System.out.print("Album title: ");
            String title = scanner.nextLine();

            System.out.print("Artist: ");
            String artist = scanner.nextLine();

            System.out.print("Release year: ");
            int year = Integer.parseInt(scanner.nextLine());

            String albumInsert = "INSERT INTO Album (Title, Artist, Year) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(albumInsert, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, title);
            pstmt.setString(2, artist);
            pstmt.setInt(3, year);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys(); //get PK of album just inserted. to use it in next insert stmnt
            rs.next();
            int albumId = rs.getInt(1);

            System.out.print("How many songs? ");
            int count = Integer.parseInt(scanner.nextLine());

            for (int i = 1; i <= count; i++) {
                System.out.print("Song " + i + " title: ");
                String songTitle = scanner.nextLine();
                String songInsert = "INSERT INTO Song (AlbumId, Title) VALUES (?, ?)";
                PreparedStatement sstmt = conn.prepareStatement(songInsert);
                sstmt.setInt(1, albumId);
                sstmt.setString(2, songTitle);
                sstmt.executeUpdate();
            }

            System.out.println("Album and songs added.");

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }

    public void editAlbumOrSongs() {
        try {
            System.out.print("Enter album ID to edit: ");
            int albumId = Integer.parseInt(scanner.nextLine());

            System.out.print("New album title: ");
            String title = scanner.nextLine();

            System.out.print("New artist: ");
            String artist = scanner.nextLine();

            System.out.print("New year: ");
            int year = Integer.parseInt(scanner.nextLine());

            String updateAlbum = "UPDATE Album SET Title = ?, Artist = ?, Year = ? WHERE AlbumId = ?";
            PreparedStatement pstmt = conn.prepareStatement(updateAlbum);
            pstmt.setString(1, title);
            pstmt.setString(2, artist);
            pstmt.setInt(3, year);
            pstmt.setInt(4, albumId);
            pstmt.executeUpdate();

            System.out.println("Album updated.");
            // Song editing omitted for brevity

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }

    public void querySongsByArtist() {
        try {
            System.out.print("Artist name: ");
            String artist = scanner.nextLine();
            String sql = "SELECT s.Title, a.Title AS AlbumTitle FROM Song s JOIN Album a ON s.AlbumId = a.AlbumId WHERE a.Artist LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + artist + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Song: " + rs.getString("Title") + ", Album: " + rs.getString("AlbumTitle"));
            }

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }

    public void querySongsByTitleKeyword() {
        try {
            System.out.print("Keyword in song title: ");
            String keyword = scanner.nextLine();
            String sql = "SELECT s.Title, a.Title AS AlbumTitle FROM Song s JOIN Album a ON s.AlbumId = a.AlbumId WHERE s.Title LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Song: " + rs.getString("Title") + ", Album: " + rs.getString("AlbumTitle"));
            }

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }

    public void queryAlbumsByTitleKeyword() {
        try {
            System.out.print("Keyword in album title: ");
            String keyword = scanner.nextLine();
            String sql = "SELECT * FROM Album WHERE Title LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Album: " + rs.getString("Title") + ", Artist: " + rs.getString("Artist") + ", Year: " + rs.getInt("Year"));
            }

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }
}